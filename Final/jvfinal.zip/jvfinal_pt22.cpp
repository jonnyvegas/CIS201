/*
Name: Jonathan Villegas
Filename: jvfinal_pt22.cpp
Description: Convert to a switch statement.
Date: 12/9/12
e-mail address: jonathan.e.villegas@gmail.com
*/

switch (code)
{
    case 1:
    cout << "The sum is " << fnum + snum << endl;
    break;

    case 2:
    cout<< "The product is" << fnum * snum << endl;
    break;

    default:
    cout << "The difference is: " << fnum << snum << endl;
}
